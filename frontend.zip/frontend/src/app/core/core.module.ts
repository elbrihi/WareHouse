import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import {ModelModule} from '../shared/models/model.module';

@NgModule({
    declarations: [],
    imports: [RouterModule],
    exports: [],
    providers: [],
   
})
export class CoreModule{
    constructor()
    {
        
    }
}