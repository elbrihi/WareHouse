import { NgModule } from "@angular/core";
import { MenuService } from "../../core/services/menu.service";


@NgModule({
    imports: [],
    providers: [MenuService]
})

export class ModelModule
{
    constructor()
    {
       
    }
}